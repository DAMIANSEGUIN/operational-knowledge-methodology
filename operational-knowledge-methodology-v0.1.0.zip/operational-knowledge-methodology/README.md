# Operational Knowledge Methodology

A repository for the client-first methodology, field guide, diagnostic system, qualification system, messaging system, implementation system, and agent instructions used to help small organizations solve operational and strategic problems.

## Start here

1. `PROJECT.md`
2. `CURRENT_STATE.md`
3. `01_strategic_review/STRATEGIC_REVIEW.md`
4. `02_gap_analysis/README.md`

## What this repository is

- A canonical source
- A field guide for approaching and helping organizations
- An agent-operable methodology
- A structured learning system
- A source for generated DOCX, PDF, web, and prompt-pack outputs

## What this repository is not

- A marketing brochure
- A generic AI consulting playbook
- A governance-first architecture
- A replacement for human judgment
- A collection of duplicated prompts
- A transcript archive

## Canonical rule

Edit source files only.

Do not edit generated files in `build/`.

## Repository map

- `00_orientation/` — plain-language explanation and system orientation
- `01_strategic_review/` — approved design brief
- `02_gap_analysis/` — comparison of current methodology against the brief
- `03_methodology/` — approved methodology after gap analysis
- `04_field_guide/` — prospect-to-client operating sequence
- `05_diagnostic/` — diagnostic model, prompts, scoring, and report structure
- `06_qualification/` — interpretation of lead responses and fit decisions
- `07_translation/` — conversion of internal intelligence into simple client language
- `08_implementation/` — engagement delivery and continuous improvement
- `09_intelligence/` — pattern library, evidence levels, analytics, and learning
- `10_campaign/` — research, outreach, conversations, and partnerships
- `11_agents/` — role definitions and execution contracts
- `12_prompts/` — canonical prompts only
- `13_templates/` — reusable output formats
- `14_governance/` — controlled change, traceability, and decision records
- `15_source_material/` — source artifacts supplied for review
- `build/` — generated outputs
- `scripts/` — build and validation scripts
